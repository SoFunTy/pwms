// $(function($) {
//     setTimeout(function () {
//         window.location.href = "/pwms_war/static/pages/common/index.html";
//     }, 1500);
// });

//对应角色显示对应模块



//菜单栏页面切换