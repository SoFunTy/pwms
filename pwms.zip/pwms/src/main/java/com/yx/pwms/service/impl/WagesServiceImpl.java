package com.yx.pwms.service.impl;

import com.yx.pwms.service.WagesService;

public class WagesServiceImpl implements WagesService {
}
