package com.yx.pwms.service;

public interface WagesService {
}
