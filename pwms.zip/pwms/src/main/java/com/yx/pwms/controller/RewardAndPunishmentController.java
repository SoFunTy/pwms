package com.yx.pwms.controller;

import org.springframework.stereotype.Controller;

@Controller
public class RewardAndPunishmentController {
}
