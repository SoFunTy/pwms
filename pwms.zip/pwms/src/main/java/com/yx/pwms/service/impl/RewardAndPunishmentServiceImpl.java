package com.yx.pwms.service.impl;

import com.yx.pwms.service.RewardAndPunishmentService;

public class RewardAndPunishmentServiceImpl implements RewardAndPunishmentService {
}
